﻿namespace Bookids
{
    partial class FormGestaoClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGestaoClientes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAjuda = new System.Windows.Forms.Button();
            this.btnSairMenu = new System.Windows.Forms.Button();
            this.pbLogoBarraFerramentas = new System.Windows.Forms.PictureBox();
            this.pictureBoxSetaVoltar = new System.Windows.Forms.PictureBox();
            this.lbDataHora = new System.Windows.Forms.Label();
            this.timerDataHora = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoBarraFerramentas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetaVoltar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnAjuda);
            this.panel1.Controls.Add(this.btnSairMenu);
            this.panel1.Controls.Add(this.pbLogoBarraFerramentas);
            this.panel1.Controls.Add(this.pictureBoxSetaVoltar);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(664, 38);
            this.panel1.TabIndex = 0;
            // 
            // btnAjuda
            // 
            this.btnAjuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjuda.Location = new System.Drawing.Point(518, 6);
            this.btnAjuda.Margin = new System.Windows.Forms.Padding(2);
            this.btnAjuda.Name = "btnAjuda";
            this.btnAjuda.Size = new System.Drawing.Size(65, 26);
            this.btnAjuda.TabIndex = 11;
            this.btnAjuda.Text = "Ajuda";
            this.btnAjuda.UseVisualStyleBackColor = true;
            this.btnAjuda.Click += new System.EventHandler(this.btnAjuda_Click);
            // 
            // btnSairMenu
            // 
            this.btnSairMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairMenu.Location = new System.Drawing.Point(587, 6);
            this.btnSairMenu.Margin = new System.Windows.Forms.Padding(2);
            this.btnSairMenu.Name = "btnSairMenu";
            this.btnSairMenu.Size = new System.Drawing.Size(65, 26);
            this.btnSairMenu.TabIndex = 10;
            this.btnSairMenu.Text = "Sair";
            this.btnSairMenu.UseVisualStyleBackColor = true;
            this.btnSairMenu.Click += new System.EventHandler(this.btnSairMenu_Click);
            // 
            // pbLogoBarraFerramentas
            // 
            this.pbLogoBarraFerramentas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbLogoBarraFerramentas.BackgroundImage")));
            this.pbLogoBarraFerramentas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbLogoBarraFerramentas.Location = new System.Drawing.Point(281, 0);
            this.pbLogoBarraFerramentas.Margin = new System.Windows.Forms.Padding(2);
            this.pbLogoBarraFerramentas.Name = "pbLogoBarraFerramentas";
            this.pbLogoBarraFerramentas.Size = new System.Drawing.Size(101, 37);
            this.pbLogoBarraFerramentas.TabIndex = 7;
            this.pbLogoBarraFerramentas.TabStop = false;
            // 
            // pictureBoxSetaVoltar
            // 
            this.pictureBoxSetaVoltar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSetaVoltar.BackgroundImage")));
            this.pictureBoxSetaVoltar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSetaVoltar.Location = new System.Drawing.Point(8, 0);
            this.pictureBoxSetaVoltar.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBoxSetaVoltar.Name = "pictureBoxSetaVoltar";
            this.pictureBoxSetaVoltar.Size = new System.Drawing.Size(32, 37);
            this.pictureBoxSetaVoltar.TabIndex = 6;
            this.pictureBoxSetaVoltar.TabStop = false;
            this.pictureBoxSetaVoltar.Click += new System.EventHandler(this.pictureBoxSetaVoltar_Click);
            // 
            // lbDataHora
            // 
            this.lbDataHora.AutoSize = true;
            this.lbDataHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold);
            this.lbDataHora.Location = new System.Drawing.Point(502, 428);
            this.lbDataHora.Name = "lbDataHora";
            this.lbDataHora.Size = new System.Drawing.Size(41, 13);
            this.lbDataHora.TabIndex = 1;
            this.lbDataHora.Text = "label1";
            this.lbDataHora.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // timerDataHora
            // 
            this.timerDataHora.Enabled = true;
            this.timerDataHora.Tick += new System.EventHandler(this.timerDataHora_Tick);
            // 
            // FormGestaoClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(662, 450);
            this.Controls.Add(this.lbDataHora);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormGestaoClientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestão de Clientes";
            this.Load += new System.EventHandler(this.FormGestaoClientes_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoBarraFerramentas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetaVoltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbLogoBarraFerramentas;
        private System.Windows.Forms.PictureBox pictureBoxSetaVoltar;
        private System.Windows.Forms.Button btnAjuda;
        private System.Windows.Forms.Button btnSairMenu;
        private System.Windows.Forms.Label lbDataHora;
        private System.Windows.Forms.Timer timerDataHora;
    }
}