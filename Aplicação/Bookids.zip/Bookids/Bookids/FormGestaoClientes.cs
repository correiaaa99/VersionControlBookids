﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bookids
{
    public partial class FormGestaoClientes : Form
    {
        funcionalidadesAplicacao funcionalidadesAplicacao = new funcionalidadesAplicacao();
        public FormGestaoClientes()
        {
            InitializeComponent(); 
        }

        private void FormGestaoClientes_Load(object sender, EventArgs e)
        {
        }

        private void btnAjuda_Click(object sender, EventArgs e)
        {
            funcionalidadesAplicacao.ajuda(this);
        }

        private void pictureBoxSetaVoltar_Click(object sender, EventArgs e)
        {
            //Abrir o form do formulário principal
            formPrincipal formPrincipal = new formPrincipal();
            funcionalidadesAplicacao.escolherForm(formPrincipal, this);
        }

        private void btnSairMenu_Click(object sender, EventArgs e)
        {
            //buscar método à class e passar por parâmetro o form
            funcionalidadesAplicacao.sair(this);
        }

        private void timerDataHora_Tick(object sender, EventArgs e)
        {
            //buscar data e hora atual
            lbDataHora.Text = funcionalidadesAplicacao.getDataHora();
        }
    }
}
