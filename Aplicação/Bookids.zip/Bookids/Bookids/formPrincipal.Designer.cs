﻿namespace Bookids
{
    partial class formPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formPrincipal));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panelGestaoClientes = new System.Windows.Forms.Panel();
            this.pbGestaoClientes = new System.Windows.Forms.PictureBox();
            this.btnGestaoClientes = new System.Windows.Forms.Button();
            this.panelGestaoParticipacoes = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnGestaoParticipacoes = new System.Windows.Forms.Button();
            this.panelGestaoFilhos = new System.Windows.Forms.Panel();
            this.pbGestaoFilhos = new System.Windows.Forms.PictureBox();
            this.btnGestaoFilhos = new System.Windows.Forms.Button();
            this.panelGestaoEscolas = new System.Windows.Forms.Panel();
            this.pbGestaoEscolas = new System.Windows.Forms.PictureBox();
            this.btnGestaoEscolas = new System.Windows.Forms.Button();
            this.panelGestaoAnimadores = new System.Windows.Forms.Panel();
            this.pbGestaoAnimadores = new System.Windows.Forms.PictureBox();
            this.btnGestaoAnimadores = new System.Windows.Forms.Button();
            this.panelGestaoProdutos = new System.Windows.Forms.Panel();
            this.pbGestaoProdutos = new System.Windows.Forms.PictureBox();
            this.btnGestaoProdutos = new System.Windows.Forms.Button();
            this.panelGestaoColaboracoes = new System.Windows.Forms.Panel();
            this.pbGestaoColaboracoes = new System.Windows.Forms.PictureBox();
            this.btnGestaoColaboracoes = new System.Windows.Forms.Button();
            this.panelGestaoTipoProduto = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnGestaoTipoProduto = new System.Windows.Forms.Button();
            this.panelGestaoEventos = new System.Windows.Forms.Panel();
            this.pbGestaoEventos = new System.Windows.Forms.PictureBox();
            this.btnGestaoEventos = new System.Windows.Forms.Button();
            this.panelGestaoCompras = new System.Windows.Forms.Panel();
            this.pbGestaoCompras = new System.Windows.Forms.PictureBox();
            this.btnGestaoCompras = new System.Windows.Forms.Button();
            this.panelGestaoDetalhesCompras = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnGestaoDetalhesCompras = new System.Windows.Forms.Button();
            this.pictureBoxSetaVoltar = new System.Windows.Forms.PictureBox();
            this.panelBarraFerramentas = new System.Windows.Forms.Panel();
            this.btnAjuda = new System.Windows.Forms.Button();
            this.btnSairMenu = new System.Windows.Forms.Button();
            this.pbLogoBarraFerramentas = new System.Windows.Forms.PictureBox();
            this.panelGestaoClientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoClientes)).BeginInit();
            this.panelGestaoParticipacoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelGestaoFilhos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoFilhos)).BeginInit();
            this.panelGestaoEscolas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoEscolas)).BeginInit();
            this.panelGestaoAnimadores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoAnimadores)).BeginInit();
            this.panelGestaoProdutos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoProdutos)).BeginInit();
            this.panelGestaoColaboracoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoColaboracoes)).BeginInit();
            this.panelGestaoTipoProduto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelGestaoEventos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoEventos)).BeginInit();
            this.panelGestaoCompras.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoCompras)).BeginInit();
            this.panelGestaoDetalhesCompras.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetaVoltar)).BeginInit();
            this.panelBarraFerramentas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoBarraFerramentas)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panelGestaoClientes
            // 
            this.panelGestaoClientes.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoClientes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoClientes.Controls.Add(this.pbGestaoClientes);
            this.panelGestaoClientes.Controls.Add(this.btnGestaoClientes);
            this.panelGestaoClientes.Location = new System.Drawing.Point(9, 68);
            this.panelGestaoClientes.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoClientes.Name = "panelGestaoClientes";
            this.panelGestaoClientes.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoClientes.TabIndex = 1;
            // 
            // pbGestaoClientes
            // 
            this.pbGestaoClientes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoClientes.BackgroundImage")));
            this.pbGestaoClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoClientes.Location = new System.Drawing.Point(3, 2);
            this.pbGestaoClientes.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoClientes.Name = "pbGestaoClientes";
            this.pbGestaoClientes.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoClientes.TabIndex = 1;
            this.pbGestaoClientes.TabStop = false;
            // 
            // btnGestaoClientes
            // 
            this.btnGestaoClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoClientes.Location = new System.Drawing.Point(43, 2);
            this.btnGestaoClientes.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoClientes.Name = "btnGestaoClientes";
            this.btnGestaoClientes.Size = new System.Drawing.Size(243, 40);
            this.btnGestaoClientes.TabIndex = 0;
            this.btnGestaoClientes.Text = "Gestão de Clientes";
            this.btnGestaoClientes.UseVisualStyleBackColor = true;
            this.btnGestaoClientes.Click += new System.EventHandler(this.btnGestaoClientes_Click);
            // 
            // panelGestaoParticipacoes
            // 
            this.panelGestaoParticipacoes.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoParticipacoes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoParticipacoes.Controls.Add(this.pictureBox2);
            this.panelGestaoParticipacoes.Controls.Add(this.btnGestaoParticipacoes);
            this.panelGestaoParticipacoes.Location = new System.Drawing.Point(364, 68);
            this.panelGestaoParticipacoes.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoParticipacoes.Name = "panelGestaoParticipacoes";
            this.panelGestaoParticipacoes.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoParticipacoes.TabIndex = 4;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(2, 2);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 38);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // btnGestaoParticipacoes
            // 
            this.btnGestaoParticipacoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoParticipacoes.Location = new System.Drawing.Point(42, 2);
            this.btnGestaoParticipacoes.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoParticipacoes.Name = "btnGestaoParticipacoes";
            this.btnGestaoParticipacoes.Size = new System.Drawing.Size(244, 40);
            this.btnGestaoParticipacoes.TabIndex = 11;
            this.btnGestaoParticipacoes.Text = "Gestão de Participações";
            this.btnGestaoParticipacoes.UseVisualStyleBackColor = true;
            // 
            // panelGestaoFilhos
            // 
            this.panelGestaoFilhos.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoFilhos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoFilhos.Controls.Add(this.pbGestaoFilhos);
            this.panelGestaoFilhos.Controls.Add(this.btnGestaoFilhos);
            this.panelGestaoFilhos.Location = new System.Drawing.Point(9, 130);
            this.panelGestaoFilhos.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoFilhos.Name = "panelGestaoFilhos";
            this.panelGestaoFilhos.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoFilhos.TabIndex = 3;
            // 
            // pbGestaoFilhos
            // 
            this.pbGestaoFilhos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoFilhos.BackgroundImage")));
            this.pbGestaoFilhos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoFilhos.Location = new System.Drawing.Point(3, 2);
            this.pbGestaoFilhos.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoFilhos.Name = "pbGestaoFilhos";
            this.pbGestaoFilhos.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoFilhos.TabIndex = 2;
            this.pbGestaoFilhos.TabStop = false;
            // 
            // btnGestaoFilhos
            // 
            this.btnGestaoFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoFilhos.Location = new System.Drawing.Point(43, 2);
            this.btnGestaoFilhos.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoFilhos.Name = "btnGestaoFilhos";
            this.btnGestaoFilhos.Size = new System.Drawing.Size(243, 40);
            this.btnGestaoFilhos.TabIndex = 1;
            this.btnGestaoFilhos.Text = "Gestão de Filhos";
            this.btnGestaoFilhos.UseVisualStyleBackColor = true;
            this.btnGestaoFilhos.Click += new System.EventHandler(this.btnGestaoFilhos_Click);
            // 
            // panelGestaoEscolas
            // 
            this.panelGestaoEscolas.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoEscolas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoEscolas.Controls.Add(this.pbGestaoEscolas);
            this.panelGestaoEscolas.Controls.Add(this.btnGestaoEscolas);
            this.panelGestaoEscolas.Location = new System.Drawing.Point(364, 130);
            this.panelGestaoEscolas.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoEscolas.Name = "panelGestaoEscolas";
            this.panelGestaoEscolas.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoEscolas.TabIndex = 4;
            // 
            // pbGestaoEscolas
            // 
            this.pbGestaoEscolas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoEscolas.BackgroundImage")));
            this.pbGestaoEscolas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoEscolas.Location = new System.Drawing.Point(2, 2);
            this.pbGestaoEscolas.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoEscolas.Name = "pbGestaoEscolas";
            this.pbGestaoEscolas.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoEscolas.TabIndex = 5;
            this.pbGestaoEscolas.TabStop = false;
            // 
            // btnGestaoEscolas
            // 
            this.btnGestaoEscolas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoEscolas.Location = new System.Drawing.Point(42, 2);
            this.btnGestaoEscolas.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoEscolas.Name = "btnGestaoEscolas";
            this.btnGestaoEscolas.Size = new System.Drawing.Size(244, 40);
            this.btnGestaoEscolas.TabIndex = 10;
            this.btnGestaoEscolas.Text = "Gestão de Escolas";
            this.btnGestaoEscolas.UseVisualStyleBackColor = true;
            // 
            // panelGestaoAnimadores
            // 
            this.panelGestaoAnimadores.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoAnimadores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoAnimadores.Controls.Add(this.pbGestaoAnimadores);
            this.panelGestaoAnimadores.Controls.Add(this.btnGestaoAnimadores);
            this.panelGestaoAnimadores.Location = new System.Drawing.Point(9, 192);
            this.panelGestaoAnimadores.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoAnimadores.Name = "panelGestaoAnimadores";
            this.panelGestaoAnimadores.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoAnimadores.TabIndex = 3;
            // 
            // pbGestaoAnimadores
            // 
            this.pbGestaoAnimadores.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoAnimadores.BackgroundImage")));
            this.pbGestaoAnimadores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoAnimadores.Location = new System.Drawing.Point(3, 2);
            this.pbGestaoAnimadores.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoAnimadores.Name = "pbGestaoAnimadores";
            this.pbGestaoAnimadores.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoAnimadores.TabIndex = 3;
            this.pbGestaoAnimadores.TabStop = false;
            // 
            // btnGestaoAnimadores
            // 
            this.btnGestaoAnimadores.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoAnimadores.Location = new System.Drawing.Point(43, 2);
            this.btnGestaoAnimadores.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoAnimadores.Name = "btnGestaoAnimadores";
            this.btnGestaoAnimadores.Size = new System.Drawing.Size(243, 40);
            this.btnGestaoAnimadores.TabIndex = 2;
            this.btnGestaoAnimadores.Text = "Gestão de Animadores";
            this.btnGestaoAnimadores.UseVisualStyleBackColor = true;
            // 
            // panelGestaoProdutos
            // 
            this.panelGestaoProdutos.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoProdutos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoProdutos.Controls.Add(this.pbGestaoProdutos);
            this.panelGestaoProdutos.Controls.Add(this.btnGestaoProdutos);
            this.panelGestaoProdutos.Location = new System.Drawing.Point(364, 192);
            this.panelGestaoProdutos.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoProdutos.Name = "panelGestaoProdutos";
            this.panelGestaoProdutos.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoProdutos.TabIndex = 4;
            // 
            // pbGestaoProdutos
            // 
            this.pbGestaoProdutos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoProdutos.BackgroundImage")));
            this.pbGestaoProdutos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoProdutos.Location = new System.Drawing.Point(2, 2);
            this.pbGestaoProdutos.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoProdutos.Name = "pbGestaoProdutos";
            this.pbGestaoProdutos.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoProdutos.TabIndex = 6;
            this.pbGestaoProdutos.TabStop = false;
            // 
            // btnGestaoProdutos
            // 
            this.btnGestaoProdutos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoProdutos.Location = new System.Drawing.Point(42, 2);
            this.btnGestaoProdutos.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoProdutos.Name = "btnGestaoProdutos";
            this.btnGestaoProdutos.Size = new System.Drawing.Size(244, 40);
            this.btnGestaoProdutos.TabIndex = 5;
            this.btnGestaoProdutos.Text = "Gestão de Produtos";
            this.btnGestaoProdutos.UseVisualStyleBackColor = true;
            this.btnGestaoProdutos.Click += new System.EventHandler(this.btnGestaoProdutos_Click);
            // 
            // panelGestaoColaboracoes
            // 
            this.panelGestaoColaboracoes.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoColaboracoes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoColaboracoes.Controls.Add(this.pbGestaoColaboracoes);
            this.panelGestaoColaboracoes.Controls.Add(this.btnGestaoColaboracoes);
            this.panelGestaoColaboracoes.Location = new System.Drawing.Point(9, 254);
            this.panelGestaoColaboracoes.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoColaboracoes.Name = "panelGestaoColaboracoes";
            this.panelGestaoColaboracoes.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoColaboracoes.TabIndex = 3;
            // 
            // pbGestaoColaboracoes
            // 
            this.pbGestaoColaboracoes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoColaboracoes.BackgroundImage")));
            this.pbGestaoColaboracoes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoColaboracoes.Location = new System.Drawing.Point(3, 2);
            this.pbGestaoColaboracoes.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoColaboracoes.Name = "pbGestaoColaboracoes";
            this.pbGestaoColaboracoes.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoColaboracoes.TabIndex = 4;
            this.pbGestaoColaboracoes.TabStop = false;
            // 
            // btnGestaoColaboracoes
            // 
            this.btnGestaoColaboracoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoColaboracoes.Location = new System.Drawing.Point(43, 2);
            this.btnGestaoColaboracoes.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoColaboracoes.Name = "btnGestaoColaboracoes";
            this.btnGestaoColaboracoes.Size = new System.Drawing.Size(243, 40);
            this.btnGestaoColaboracoes.TabIndex = 8;
            this.btnGestaoColaboracoes.Text = "Gestão de Colaborações";
            this.btnGestaoColaboracoes.UseVisualStyleBackColor = true;
            // 
            // panelGestaoTipoProduto
            // 
            this.panelGestaoTipoProduto.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoTipoProduto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoTipoProduto.Controls.Add(this.pictureBox1);
            this.panelGestaoTipoProduto.Controls.Add(this.btnGestaoTipoProduto);
            this.panelGestaoTipoProduto.Location = new System.Drawing.Point(364, 254);
            this.panelGestaoTipoProduto.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoTipoProduto.Name = "panelGestaoTipoProduto";
            this.panelGestaoTipoProduto.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoTipoProduto.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 38);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // btnGestaoTipoProduto
            // 
            this.btnGestaoTipoProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoTipoProduto.Location = new System.Drawing.Point(42, 2);
            this.btnGestaoTipoProduto.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoTipoProduto.Name = "btnGestaoTipoProduto";
            this.btnGestaoTipoProduto.Size = new System.Drawing.Size(244, 40);
            this.btnGestaoTipoProduto.TabIndex = 6;
            this.btnGestaoTipoProduto.Text = "Gestão de Tipos de Produtos";
            this.btnGestaoTipoProduto.UseVisualStyleBackColor = true;
            this.btnGestaoTipoProduto.Click += new System.EventHandler(this.btnGestaoTipoProduto_Click);
            // 
            // panelGestaoEventos
            // 
            this.panelGestaoEventos.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoEventos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoEventos.Controls.Add(this.pbGestaoEventos);
            this.panelGestaoEventos.Controls.Add(this.btnGestaoEventos);
            this.panelGestaoEventos.Location = new System.Drawing.Point(9, 316);
            this.panelGestaoEventos.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoEventos.Name = "panelGestaoEventos";
            this.panelGestaoEventos.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoEventos.TabIndex = 3;
            // 
            // pbGestaoEventos
            // 
            this.pbGestaoEventos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoEventos.BackgroundImage")));
            this.pbGestaoEventos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoEventos.Location = new System.Drawing.Point(3, 2);
            this.pbGestaoEventos.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoEventos.Name = "pbGestaoEventos";
            this.pbGestaoEventos.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoEventos.TabIndex = 8;
            this.pbGestaoEventos.TabStop = false;
            // 
            // btnGestaoEventos
            // 
            this.btnGestaoEventos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoEventos.Location = new System.Drawing.Point(43, 2);
            this.btnGestaoEventos.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoEventos.Name = "btnGestaoEventos";
            this.btnGestaoEventos.Size = new System.Drawing.Size(243, 40);
            this.btnGestaoEventos.TabIndex = 7;
            this.btnGestaoEventos.Text = "Gestão de Eventos";
            this.btnGestaoEventos.UseVisualStyleBackColor = true;
            // 
            // panelGestaoCompras
            // 
            this.panelGestaoCompras.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoCompras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoCompras.Controls.Add(this.pbGestaoCompras);
            this.panelGestaoCompras.Controls.Add(this.btnGestaoCompras);
            this.panelGestaoCompras.Location = new System.Drawing.Point(364, 315);
            this.panelGestaoCompras.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoCompras.Name = "panelGestaoCompras";
            this.panelGestaoCompras.Size = new System.Drawing.Size(290, 46);
            this.panelGestaoCompras.TabIndex = 4;
            // 
            // pbGestaoCompras
            // 
            this.pbGestaoCompras.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGestaoCompras.BackgroundImage")));
            this.pbGestaoCompras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbGestaoCompras.Location = new System.Drawing.Point(2, 2);
            this.pbGestaoCompras.Margin = new System.Windows.Forms.Padding(2);
            this.pbGestaoCompras.Name = "pbGestaoCompras";
            this.pbGestaoCompras.Size = new System.Drawing.Size(35, 38);
            this.pbGestaoCompras.TabIndex = 4;
            this.pbGestaoCompras.TabStop = false;
            // 
            // btnGestaoCompras
            // 
            this.btnGestaoCompras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoCompras.Location = new System.Drawing.Point(42, 2);
            this.btnGestaoCompras.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoCompras.Name = "btnGestaoCompras";
            this.btnGestaoCompras.Size = new System.Drawing.Size(244, 40);
            this.btnGestaoCompras.TabIndex = 3;
            this.btnGestaoCompras.Text = "Gestão de Compras";
            this.btnGestaoCompras.UseVisualStyleBackColor = true;
            // 
            // panelGestaoDetalhesCompras
            // 
            this.panelGestaoDetalhesCompras.BackColor = System.Drawing.Color.Silver;
            this.panelGestaoDetalhesCompras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGestaoDetalhesCompras.Controls.Add(this.pictureBox3);
            this.panelGestaoDetalhesCompras.Controls.Add(this.btnGestaoDetalhesCompras);
            this.panelGestaoDetalhesCompras.Location = new System.Drawing.Point(209, 375);
            this.panelGestaoDetalhesCompras.Margin = new System.Windows.Forms.Padding(2);
            this.panelGestaoDetalhesCompras.Name = "panelGestaoDetalhesCompras";
            this.panelGestaoDetalhesCompras.Size = new System.Drawing.Size(256, 55);
            this.panelGestaoDetalhesCompras.TabIndex = 3;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(2, 2);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(44, 48);
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // btnGestaoDetalhesCompras
            // 
            this.btnGestaoDetalhesCompras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestaoDetalhesCompras.Location = new System.Drawing.Point(50, 2);
            this.btnGestaoDetalhesCompras.Margin = new System.Windows.Forms.Padding(2);
            this.btnGestaoDetalhesCompras.Name = "btnGestaoDetalhesCompras";
            this.btnGestaoDetalhesCompras.Size = new System.Drawing.Size(202, 48);
            this.btnGestaoDetalhesCompras.TabIndex = 4;
            this.btnGestaoDetalhesCompras.Text = "Gestão de Detalhes de Compras";
            this.btnGestaoDetalhesCompras.UseVisualStyleBackColor = true;
            this.btnGestaoDetalhesCompras.Click += new System.EventHandler(this.btnGestaoDetalhesCompras_Click);
            // 
            // pictureBoxSetaVoltar
            // 
            this.pictureBoxSetaVoltar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSetaVoltar.BackgroundImage")));
            this.pictureBoxSetaVoltar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSetaVoltar.Location = new System.Drawing.Point(8, 0);
            this.pictureBoxSetaVoltar.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBoxSetaVoltar.Name = "pictureBoxSetaVoltar";
            this.pictureBoxSetaVoltar.Size = new System.Drawing.Size(32, 37);
            this.pictureBoxSetaVoltar.TabIndex = 5;
            this.pictureBoxSetaVoltar.TabStop = false;
            this.pictureBoxSetaVoltar.Click += new System.EventHandler(this.pictureBoxSetaVoltar_Click);
            // 
            // panelBarraFerramentas
            // 
            this.panelBarraFerramentas.BackColor = System.Drawing.Color.Silver;
            this.panelBarraFerramentas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBarraFerramentas.Controls.Add(this.btnAjuda);
            this.panelBarraFerramentas.Controls.Add(this.btnSairMenu);
            this.panelBarraFerramentas.Controls.Add(this.pbLogoBarraFerramentas);
            this.panelBarraFerramentas.Controls.Add(this.pictureBoxSetaVoltar);
            this.panelBarraFerramentas.Location = new System.Drawing.Point(0, 0);
            this.panelBarraFerramentas.Margin = new System.Windows.Forms.Padding(2);
            this.panelBarraFerramentas.Name = "panelBarraFerramentas";
            this.panelBarraFerramentas.Size = new System.Drawing.Size(664, 38);
            this.panelBarraFerramentas.TabIndex = 2;
            // 
            // btnAjuda
            // 
            this.btnAjuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjuda.Location = new System.Drawing.Point(518, 6);
            this.btnAjuda.Margin = new System.Windows.Forms.Padding(2);
            this.btnAjuda.Name = "btnAjuda";
            this.btnAjuda.Size = new System.Drawing.Size(65, 26);
            this.btnAjuda.TabIndex = 9;
            this.btnAjuda.Text = "Ajuda";
            this.btnAjuda.UseVisualStyleBackColor = true;
            this.btnAjuda.Click += new System.EventHandler(this.btnAjuda_Click);
            // 
            // btnSairMenu
            // 
            this.btnSairMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairMenu.Location = new System.Drawing.Point(587, 6);
            this.btnSairMenu.Margin = new System.Windows.Forms.Padding(2);
            this.btnSairMenu.Name = "btnSairMenu";
            this.btnSairMenu.Size = new System.Drawing.Size(65, 26);
            this.btnSairMenu.TabIndex = 8;
            this.btnSairMenu.Text = "Sair";
            this.btnSairMenu.UseVisualStyleBackColor = true;
            this.btnSairMenu.Click += new System.EventHandler(this.btnSairMenu_Click);
            // 
            // pbLogoBarraFerramentas
            // 
            this.pbLogoBarraFerramentas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbLogoBarraFerramentas.BackgroundImage")));
            this.pbLogoBarraFerramentas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbLogoBarraFerramentas.Location = new System.Drawing.Point(280, -1);
            this.pbLogoBarraFerramentas.Margin = new System.Windows.Forms.Padding(2);
            this.pbLogoBarraFerramentas.Name = "pbLogoBarraFerramentas";
            this.pbLogoBarraFerramentas.Size = new System.Drawing.Size(101, 37);
            this.pbLogoBarraFerramentas.TabIndex = 6;
            this.pbLogoBarraFerramentas.TabStop = false;
            // 
            // formPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(662, 450);
            this.Controls.Add(this.panelBarraFerramentas);
            this.Controls.Add(this.panelGestaoCompras);
            this.Controls.Add(this.panelGestaoDetalhesCompras);
            this.Controls.Add(this.panelGestaoTipoProduto);
            this.Controls.Add(this.panelGestaoEventos);
            this.Controls.Add(this.panelGestaoProdutos);
            this.Controls.Add(this.panelGestaoEscolas);
            this.Controls.Add(this.panelGestaoColaboracoes);
            this.Controls.Add(this.panelGestaoAnimadores);
            this.Controls.Add(this.panelGestaoParticipacoes);
            this.Controls.Add(this.panelGestaoFilhos);
            this.Controls.Add(this.panelGestaoClientes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestão - Bookids";
            this.Load += new System.EventHandler(this.formPrincipal_Load);
            this.panelGestaoClientes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoClientes)).EndInit();
            this.panelGestaoParticipacoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelGestaoFilhos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoFilhos)).EndInit();
            this.panelGestaoEscolas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoEscolas)).EndInit();
            this.panelGestaoAnimadores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoAnimadores)).EndInit();
            this.panelGestaoProdutos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoProdutos)).EndInit();
            this.panelGestaoColaboracoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoColaboracoes)).EndInit();
            this.panelGestaoTipoProduto.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelGestaoEventos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoEventos)).EndInit();
            this.panelGestaoCompras.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGestaoCompras)).EndInit();
            this.panelGestaoDetalhesCompras.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetaVoltar)).EndInit();
            this.panelBarraFerramentas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbLogoBarraFerramentas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panelGestaoClientes;
        private System.Windows.Forms.Panel panelGestaoParticipacoes;
        private System.Windows.Forms.Panel panelGestaoFilhos;
        private System.Windows.Forms.Panel panelGestaoEscolas;
        private System.Windows.Forms.Panel panelGestaoAnimadores;
        private System.Windows.Forms.Panel panelGestaoProdutos;
        private System.Windows.Forms.Panel panelGestaoColaboracoes;
        private System.Windows.Forms.Panel panelGestaoTipoProduto;
        private System.Windows.Forms.Panel panelGestaoEventos;
        private System.Windows.Forms.Panel panelGestaoCompras;
        private System.Windows.Forms.Panel panelGestaoDetalhesCompras;
        private System.Windows.Forms.PictureBox pictureBoxSetaVoltar;
        private System.Windows.Forms.Panel panelBarraFerramentas;
        private System.Windows.Forms.Button btnGestaoClientes;
        private System.Windows.Forms.Button btnGestaoTipoProduto;
        private System.Windows.Forms.Button btnGestaoEventos;
        private System.Windows.Forms.Button btnGestaoFilhos;
        private System.Windows.Forms.Button btnGestaoColaboracoes;
        private System.Windows.Forms.Button btnGestaoAnimadores;
        private System.Windows.Forms.Button btnGestaoCompras;
        private System.Windows.Forms.Button btnGestaoEscolas;
        private System.Windows.Forms.Button btnGestaoDetalhesCompras;
        private System.Windows.Forms.Button btnGestaoParticipacoes;
        private System.Windows.Forms.Button btnGestaoProdutos;
        private System.Windows.Forms.PictureBox pbLogoBarraFerramentas;
        private System.Windows.Forms.PictureBox pbGestaoClientes;
        private System.Windows.Forms.PictureBox pbGestaoFilhos;
        private System.Windows.Forms.PictureBox pbGestaoAnimadores;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pbGestaoEscolas;
        private System.Windows.Forms.PictureBox pbGestaoProdutos;
        private System.Windows.Forms.PictureBox pbGestaoColaboracoes;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbGestaoEventos;
        private System.Windows.Forms.PictureBox pbGestaoCompras;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnAjuda;
        private System.Windows.Forms.Button btnSairMenu;
    }
}